import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {

	private new_prod: any;

  constructor(private ps:ProductService, private route:Router, private activatedRoute: ActivatedRoute) {

   }

  ngOnInit() {
  	this.new_prod = {
  		name:"",
  		qty:"",
  		price:""
  	}
  }

  create_prod(){
  	this.ps.create(this.new_prod,(data)=>{
      if(data.errors){
        console.log(data.errors)
      }
      else{
      	console.log(data);
        this.route.navigate([""]);
      }
  	});
  }

}
