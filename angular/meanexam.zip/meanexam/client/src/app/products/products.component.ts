import { Component, OnInit } from '@angular/core';
import {ProductService} from "../product.service";
import { ActivatedRoute, Params, Router } from '@angular/router';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

	private lists: any;
  constructor(private ps: ProductService) {

  }

  ngOnInit() {
    this.ps.all((data)=>{
      console.log(data);
      this.lists = data;
    }) 
  }


}
