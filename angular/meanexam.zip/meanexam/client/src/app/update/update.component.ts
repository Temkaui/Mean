import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import {ActivatedRoute, Router, Params} from "@angular/router";

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  	private info: any;
	private id: any;
  constructor(private ps:ProductService, private route:ActivatedRoute, private router: Router) {

   }

	ngOnInit() {
		this.route.params.subscribe(params=>{
			this.id = params['id'];
		});

		this.ps.show(this.id,(data)=>{
			console.log(data);
			this.info = data;
	}) 
	}

	update(){
		this.ps.update(this.info,(data)=>{
			this.info = data;
			this.router.navigate(["show" + id])
		})
	}
}
