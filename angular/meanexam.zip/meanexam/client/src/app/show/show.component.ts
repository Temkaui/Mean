import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import {ActivatedRoute, Router, Params} from "@angular/router";

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
	private info: any;
	private id: any;
  constructor(private ps:ProductService, private route:ActivatedRoute, private router: Router) {

   }

	ngOnInit() {
		this.route.params.subscribe(params=>{
			this.id = params['id'];
		});

		this.ps.show(this.id,(data)=>{
			console.log(data);
			this.info = data;
	}) 
	}


	destroy(){
		this.ps.destroy(this.id,(data)=>{
			this.router.navigate(["details" + this.id]);

		}
	}
}
