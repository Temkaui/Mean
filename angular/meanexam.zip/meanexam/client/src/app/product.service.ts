import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable()
export class ProductService {

  constructor(private http:HttpClient) { 
  
  }
  all(cb){
  	this.http.get("/api/all")
  	.subscribe(data=>{
      console.log(data);
      cb(data);
    }); 	
  }

  show(id,cb){
    console.log(id);
  	this.http.get("/api/show/"+id)
  	.subscribe(data=>{
      console.log(data);
      cb(data);
    });
  }

  create(prods,cb){
  	this.http.post("/api/new", prods)
    .subscribe(data=>cb(data));
    

  }

  update(prods, cb){
  	this.http.put("/api/edit/"+prods._id, prods)
  	.subscribe(data=>cb(data));
  }

  destroy(id,cb){
  	this.http.delete("/api/delete/"+id)
  	.subscribe(data=>cb(data));
  }

}
