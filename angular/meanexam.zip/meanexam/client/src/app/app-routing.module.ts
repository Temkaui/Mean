import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductsComponent } from './products/products.component';
import { NewComponent } from './new/new.component';
import { ShowComponent } from './show/show.component';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [
	{path:"", pathMatch:"full", component: ProductsComponent},
	{path:"new", component:NewComponent},
	{path:"edit/:id", component:UpdateComponent},
	{path:"details/:id", component:ShowComponent},
	{path:"**",redirectTo:""}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }